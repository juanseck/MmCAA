%  Majority minority Cellular Automata Algorithm (MmCAA)
%
%  Source codes version 1.0
%
%  Developed in MATLAB R2015a(7.08)
%
%  Author and programmer: Juan Carlos Seck Tuoh Mora
%
%       email:   jseck@uaeh.edu.mx
%                juanseck@gmail.com
%
%       Homepage:
%
%  Main paper: A majority-minority cellular automata algorithm for global optimization 
%  Autores: Juan Carlos Seck-Tuoh-Mora, Norberto Hernandez-Romero, Fredy Santander-Baños, 
%  Valeria Volpi-Leon, Joselito Medina-Marin, Pedro Lagos-Eulogio
%  Expert Systems With Applications, DOI: http://
%_______________________________________________________________________________________________
% You can simply define your cost function in a seperate file and load its handle to fobj
% The initial parameters that you need are:
%__________________________________________
% SmartCells_no = number of smart-cells
% Neighbors_no = number of neighbors
% Max_iteration = maximum number of iterations
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% dim = number of variables to be tunned
% fobj = @YourCostFunction
%
% If all the variables have equal bounds you can just define lb and ub as two single numbers
%
% To run MmCAA: [min_value,position_vector,convergence_curve]= MmCAA(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,fobj)
%
% Example: 
% [lb,ub,dim,fobj] = benchmark_functions('F10');
% dim = 500;
% [min_value,position_vector,convergence_curve]=MmCAA(12,6,500,lb,ub,dim,fobj)
%______________________________________________________________________________________________

function [min_value,position_vector,convergence_curve,smart_cells] = MmCAA(SmartCells_no,Neighbors_no,Max_iteration,lb,ub,dim,fcosto,bandera_imp)

%Se simplificaron reglas de la versión 4, uniendo varias con el mismo
%funcionamiento y que solo tenian condiciones distintas


%Numero de reglas
nr=6;

%Parámetros del algoritmo
%paso=(2.3-1.5)/Max_iteration;
%dist_mayor=2.3:-paso:1.5;       
dist_mayor(1:Max_iteration)=1.7;       %1   1.7
num_dec_inf=2;      %1  2
num_dec_sup=6;      %4  6

%Generate random smart-cells
[smart_cells] = generar_poblacion(SmartCells_no,lb,ub,dim);
new_smart_cells=smart_cells;

%Evalute fitness of smart-cells
[calificacion] = calificar_poblacion(smart_cells,fcosto);
new_calificacion = calificacion;
convergence_curve=zeros(1,Max_iteration);
convergence_curve(1)=min(calificacion);

%Número de soluciones elitistas
elitist_num=2;


%Optimization cycle
for i=2:Max_iteration
    %Imprime numero de iteracion
    if bandera_imp>0
        if mod(i,bandera_imp)==0
            disp(['MmCAA Iteracion: ' num2str(i) ' Valor: ' num2str(new_calificacion(1))]);
        end
    end
    %Elitism, dejar el mejor en la nueva poblacion
    [~,indE]=mink(calificacion,elitist_num);
    new_smart_cells(1:elitist_num,:)=smart_cells(indE,:);
    new_calificacion(1:elitist_num)=calificacion(indE);
    %Mejor calificacion
    mejor_calif=new_calificacion(1);
    %Tomara todas las smart-cells
    for j=elitist_num+1:SmartCells_no
        %Smart-cell actual
        smart=smart_cells(j,:);
        calif=calificacion(j);
        %Vecino 1, smart-cell aleatorio
        indA=randi(SmartCells_no);
        vecino1=smart_cells(indA,:);
        calif1=calificacion(indA);
        %Mejor de cada vecindad
        nueva_calif=inf;        
        %Neighborhoods of non-elitist solutions
        for k=1:Neighbors_no
            %Elegir regla de forma aleatoria
            regla_ale=randi([1,nr]);
            %Reglas de mutación por mayoría o minoría
            if regla_ale == 1 
                evolucion = regla_mayoria_solo(smart,dist_mayor(i)); % Explotación
            elseif regla_ale == 2
                evolucion = regla_minoria_solo(smart,dist_mayor(i)); % Exploración
            elseif regla_ale == 3 %Explotación
                evolucion = regla_redondeo_solo(smart,calif,mejor_calif,randi([num_dec_inf,num_dec_sup]));
            elseif regla_ale == 4 %Exploración
                evolucion = regla_mayoria_vecino(smart,calif,vecino1,calif1,dist_mayor(i));
            elseif regla_ale == 5 %Exploración
                evolucion = regla_minoria_vecino(smart,calif,vecino1,calif1,dist_mayor(i));
            elseif regla_ale == 6 %Exploración
                % Seleccionar una solución elitista aleatoria
                ind1=randi([1 elitist_num]);
                vecino_elite1=new_smart_cells(ind1,:);
                calif_elite1=new_calificacion(ind1);                
                ind2=randi([1 elitist_num]);
                vecino_elite2=new_smart_cells(ind2,:);
                calif_elite2=new_calificacion(ind2);
                evolucion = regla_minoria_tres_vecinos(smart,calif,vecino_elite1,calif_elite1,vecino_elite2,calif_elite2,dist_mayor(i));
            end
            %Pasar valores de evolucion a intervalo valido
            ind_Neg=evolucion<lb;
            if sum(ind_Neg)>0
                if length(lb)>1
                    evolucion(ind_Neg)=lb(ind_Neg)+(((ub(ind_Neg)-lb(ind_Neg))/4)*rand);
                else
                    evolucion(ind_Neg)=lb+((ub-lb)/4)*rand;
                end
            end
            ind_Pos=evolucion>ub;
            if sum(ind_Pos)>0
                if length(ub)>1
                    evolucion(ind_Pos)=ub(ind_Pos)-(((ub(ind_Pos)-lb(ind_Pos))/4)*rand);
                else
                    evolucion(ind_Pos)=ub-((ub-lb)/4)*rand;
                end
            end
            %Calificar vecino
            calif_evolucion = fcosto(evolucion);
            %Best of every neighborhood
            if k==1 || calif_evolucion<nueva_calif                
                mejor_vecino=evolucion;
                nueva_calif=calif_evolucion;
            end
        end
        %Ver si se cambia a la smart cell apara conservar diversidad
        if rand < 0.25 || nueva_calif<calif
            smart=mejor_vecino;
            calif=nueva_calif;
        end            
        %Agregar a new_smart_cells
        new_smart_cells(j,:)=smart;
        new_calificacion(j)=calif;
    end
    %Pasar la nueva poblacion y su calificacion a la actual
    smart_cells=new_smart_cells;
    calificacion=new_calificacion;
    convergence_curve(i)=min(calificacion);
end

%Return the best obtained solution
[min_value,indE]=min(calificacion);
position_vector=smart_cells(indE,:);

end

%Reglas

%Regla para acercar cada elemento del vector al valor mayoritario
function [evolucion] = regla_mayoria_solo(smart,proporcion)
evolucion=smart;
[x,e]=histcounts(smart);
[~,ind]=max(x);
valor=sum(e(ind:ind+1))/2;
%nueva distancia
dist=(smart-valor)*proporcion*rand;
evolucion=evolucion-dist;
end

%Regla para acercar cada elemento del vector al valor minoritario
function [evolucion] = regla_minoria_solo(smart,proporcion)
evolucion=smart;
[x,e]=histcounts(smart);
[~,ind]=min(x);
valor=sum(e(ind:ind+1))/2;
%nueva distancia
dist=(smart-valor)*proporcion*rand;
evolucion=evolucion-dist;
end

%Regla para redondeo en los valores de la smart_cell
function [evolucion] = regla_redondeo_solo(smart,calif,mejor_calif,num_dec)
evolucion=smart;
%suma de calificaciones
suma=calif+mejor_calif;
%ponderacion de calificación del vecino
pond=1-(calif/suma);
%Hacer redondeo
for i=1:length(smart)
    if rand<=pond
        evolucion(i)=round(evolucion(i),num_dec);
    end
end
end

%DOS VECINOS
%Regla para tomar mayoria del vecino para ponderar aleatoriamente dependiendo costos de los dos vecinos
function [evolucion] = regla_mayoria_vecino(smart,calif1,vecino,calif2,proporcion)
%La evolucion de la smart-cell 
evolucion=smart;
%suma de calificaciones
suma=calif1+calif2;
%ponderacion de calificación del vecino
pond=1-(calif2/suma);
%elemento mayoritaria del vecino
[x,e]=histcounts(vecino);
[~,ind]=max(x);
valor=sum(e(ind:ind+1))/2;
%Si se selecciona al vecino, se suma al elemento del vector multiplicado
%por un aletorio r entre -dist_mayor/2 y dist_mayor/2
r=(rand*proporcion)-(proporcion/2);
for i=1:length(smart)
    if rand<=pond
        evolucion(i)=evolucion(i)+(r*valor);
    end
end
end

%Regla para tomar minoría del vecino para ponderar aleatoriamente dependiendo costos de los dos vecinos
function [evolucion] = regla_minoria_vecino(smart,calif1,vecino,calif2,proporcion)
%La evolucion de la smart-cell 
evolucion=smart;
%suma de calificaciones
suma=calif1+calif2;
%ponderacion de calificación del vecino
pond=1-(calif2/suma);
%elemento mayoritaria del vecino
[x,e]=histcounts(vecino);
[~,ind]=min(x);
valor=sum(e(ind:ind+1))/2;
%Si se selecciona al vecino, se suma al elemento del vector multiplicado
%por un aletorio r entre -dist_mayor/2 y dist_mayor/2
r=(rand*proporcion)-(proporcion/2);
for i=1:length(smart)
    if rand<=pond
        evolucion(i)=evolucion(i)+(r*valor);
    end
end
end

%Regla para tomar minoría de tres vecinos ponderando aleatoriamente sus costos
function [evolucion] = regla_minoria_tres_vecinos(smart,calif,vecino1,calif1,vecino2,calif2,proporcion)
%La evolucion de la smart-cell 
evolucion=smart;
valor=smart;
%suma de calificaciones
suma=calif+calif1+calif2;
%ponderacion de calificación del vecino
pond=calif/suma;
%elemento mayoritario para cada posición en los tres vecinos
%Obtener distancias entre vecinos
dist1=abs(smart-vecino1);
dist2=abs(vecino1-vecino2);
dist3=abs(vecino2-smart);
dist=[dist1; dist2; dist3];
%Obtener indice de distancia menor por cada posicion
[~,pos]=min(dist);
%Obtener valor que no esté a mínima distancia
vecindad=[smart; vecino1; vecino2; smart];
for i=1:length(smart)
    ind=pos(i)-1;
    if ind==0
        ind=3;
    end
    valor(i)=vecindad(ind,i);
end
%Si se selecciona la posición para modificación, se suma al elemento del vector multiplicado
%por un aletorio r entre -dist_mayor/2 y dist_mayor/2
r=(rand*proporcion)-(proporcion/2);
for i=1:length(smart)
    if rand<=pond
        evolucion(i)=evolucion(i)+(r*valor(i));
    end
end
end

